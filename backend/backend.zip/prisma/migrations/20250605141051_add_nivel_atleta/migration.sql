-- AlterTable
ALTER TABLE "Atleta" ADD COLUMN     "nivel" TEXT;
