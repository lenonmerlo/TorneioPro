// 📁 backend/src/routes/usuario/authRoutes.ts
import { Router } from 'express';
import { createLogin, createRegister } from '../../controllers/usuario/authController';

const router = Router();

router.post('/login', createLogin);
router.post('/register', createRegister);

export default router;
