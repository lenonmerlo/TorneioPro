import express from 'express';
import {
  getTreinadores,
  getTreinadorById,
  createTreinador,
  updateTreinador,
  deleteTreinador
} from '../../controllers/usuario/treinadorController';

const router = express.Router(); // <-- aqui é o ponto-chave!

router.get('/', getTreinadores);
router.get('/:id', getTreinadorById);
router.post('/', createTreinador);
router.put('/:id', updateTreinador);
router.delete('/:id', deleteTreinador);

export default router;
