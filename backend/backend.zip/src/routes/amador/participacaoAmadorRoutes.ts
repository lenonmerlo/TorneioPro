// 📁 backend/src/routes/amador/participacaoAmadorRoutes.ts
import { Router } from 'express';
import {
  getInscritosAmador,
  createParticipacaoAmador,
  updateInscricaoAmador,
  deleteInscricaoAmador,
} from '../../controllers/amador/participacaoAmadorController';

const router = Router();

// GET /torneio-amador/inscritos/:torneioId
router.get('/inscritos/:torneioId', getInscritosAmador);

// POST /torneio-amador/inscricao
router.post('/inscricao', createParticipacaoAmador);

// PUT /torneio-amador/inscricao/:id
router.put('/inscricao/:id', updateInscricaoAmador);

// DELETE /torneio-amador/inscricao/:id
router.delete('/inscricao/:id', deleteInscricaoAmador);

export default router;
