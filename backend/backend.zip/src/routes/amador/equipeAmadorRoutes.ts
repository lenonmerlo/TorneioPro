// backend/src/routes/amador/equipeAmadorRoutes.ts
import { Router } from 'express';
import { getEquipesAmador } from '../../controllers/amador/equipeAmadorController';

const router = Router();

// GET /equipes-amador/:torneioId
router.get('/equipes-amador/:torneioId', getEquipesAmador);

export default router;
