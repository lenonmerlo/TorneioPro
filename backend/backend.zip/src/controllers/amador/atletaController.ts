// 📁 backend/src/controllers/amador/atletaController.ts

import { Request, Response } from 'express';
import prisma from '../../lib/prismaClient';

// Função para criar atleta
export const createAtleta = async (req: Request, res: Response) => {
  const { nome, email, genero, nivel, usuarioId } = req.body;

  if (!nome || !email || !genero || !usuarioId) {
    return res.status(400).json({ message: 'Dados obrigatórios faltando.' });
  }

  try {
    const novoAtleta = await prisma.atleta.create({
      data: {
        nome,
        email,
        genero,
        nivel,
        usuario: { connect: { id: usuarioId } },
      },
    });

    return res.status(201).json(novoAtleta);
  } catch (error) {
    console.error('Erro ao criar atleta:', error);
    return res.status(500).json({ message: 'Erro interno ao criar atleta.' });
  }
};

// Outras funções também devem ser ajustadas com base no relacionamento correto
